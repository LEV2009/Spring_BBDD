package com.packtpub.springboot2taximodel.enums;

public enum TaxiBookingStatus {
    ACTIVE,CANCELLED,COMPLETED;
}
