package com.packtpub.springboot2taximodel.enums;

public enum TaxiStatus {
    OCCUPIED,AVAILABLE;
}
