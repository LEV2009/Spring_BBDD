package com.packtpub.springboot2taximodel.enums;

public enum TaxiType {
    MINI,NANO,VAN;
}
