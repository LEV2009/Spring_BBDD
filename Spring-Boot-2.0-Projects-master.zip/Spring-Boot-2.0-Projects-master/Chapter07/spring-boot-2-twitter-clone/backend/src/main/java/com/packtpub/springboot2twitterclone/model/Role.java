package com.packtpub.springboot2twitterclone.model;

public enum Role {
    ADMIN, USER
}
