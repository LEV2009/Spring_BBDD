# A new react state management framework

#### Language: English | [Chinese](./README_zh_CN.md)

> Note:
>
> **GraphQL style, but not GraphQL only**
>
> For REST services, this framework can map them to GraphQL services on the client side, it can access REST services with GraphQL's powerful semantics!

## This framework provides three major functions
1. Simple state management: similar to [recoil](https://github.com/facebookexperimental/Recoil)
2. **Graph state management**: 
   
   The core value of this framework, it provides normalized cache far intelligent than [Apollo Client](https://github.com/apollographql/apollo-client) and [Relay](https://github.com/facebook/relay). 

   > **It can automatically guarantees consistency of local cache. After mutation, you neither need to write complex code to update the local cache, nor do you need to determine which queries will be affected by the mutation and need to be refetched**
   
   *Let's think about a few cases:*
   1. *Modify some fields of an object, because the associated collections of other objects may contain filter conditions, does the modified object match these filter conditions? Is it possible that it needs to be added to some collections? Is it possible that it needs to disappear from some collections?*
   2. *Modify some fields of an object. If the associated collections of other objects use these fields to sort at the business level, do those collections need to be reodered?*
   3. *Insert an object. Is it possible that it needs to be automatically added to the associated collection of other objects? If necessary, where to add it?*
   4. *Link the **A** object to an associated field of the **B** object, or unlink the **A** object from an associated field of the **B** object. If the **A** object also has a reverse associated field that references the **B** object, is this reverse associated field also need to be modified?*

   Please view [Project Background](./site/background.md) to know more
3. HTTP optimization: reduce the number of HTTP requests through merge requests and reuse

## Table of contents
- [Project background](./site/background.md)
- [Functions and GIF animation demonstrations](./site/function-and-gif.md)
- [Get start](./site/get-start.md)
- [Run attached demos](./site/run-demo.md)
- [Documentation](./doc/README.md)
