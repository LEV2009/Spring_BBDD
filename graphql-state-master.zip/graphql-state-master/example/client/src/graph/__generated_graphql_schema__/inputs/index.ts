export type {BookStoreInput} from './BookStoreInput';
export type {BookInput} from './BookInput';
export type {AuthorInput} from './AuthorInput';
