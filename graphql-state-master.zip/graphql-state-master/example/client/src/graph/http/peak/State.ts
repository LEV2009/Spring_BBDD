import { createState } from "../../__generated_graphql_schema__";

export const bookNameState = createState(
    "http-peak-clipping-demo-book-name", 
    ""
);