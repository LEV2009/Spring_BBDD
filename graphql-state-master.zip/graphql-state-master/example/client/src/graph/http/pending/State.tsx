import { createState } from "../../__generated_graphql_schema__";

export const bookNameState = createState("http-pending-demo-book-name", "");

export const DELAY_MILLIS = 4000;