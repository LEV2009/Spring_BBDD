import { createState } from "../../__generated_graphql_schema__";

export const bookNameState = createState<string | undefined>("http-shape-demo-book-name", undefined); 