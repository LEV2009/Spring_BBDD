export interface Command {

    redo(): void;

    undo(): void;
}