import { Record } from "./Record";

export interface RecordRef {
    readonly value?: Record;
}