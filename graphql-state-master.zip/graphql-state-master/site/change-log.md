# Change Log

|Version|Description|Required version of graphql-ts-client|
|-------|-----------|------------|
|0.2.0|Documentation|>=3.0.8|
|0.1.2|**Support REST**|>=3.0.8|
|0.1.1|Fix bugs|>=3.0.8|
|0.1.0 |**First stable version, with full documentation**|>=3.0.8||
|0.0.6 ~ 0.0.8 |Fix bugs|>=3.0.8|
|0.0.5 |Internal change|>=3.0.8|
|0.0.4 |Support releasePolicy|>=3.0.8|
|0.0.3 |Make smart mutation smarter|>=3.0.8|
|0.0.2 |**Support paging query API: usePaginationQuery**|>=3.0.8|
|0.0.1 |**Add a garbage collector to the built-in cache database**|>=3.0.7|
|0.0.0 |**First version**|>=3.0.4|
------------

[Back to home](https://github.com/babyfish-ct/graphql-state)
